#!/bin/sh

./qbsp out.map
./light out.map
./vis out.map

