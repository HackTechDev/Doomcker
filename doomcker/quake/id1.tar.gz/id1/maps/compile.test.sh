#!/bin/sh

./qbsp test.map
./light test.map
./vis test.map

