#!/bin/sh

./fteqcc.bin
